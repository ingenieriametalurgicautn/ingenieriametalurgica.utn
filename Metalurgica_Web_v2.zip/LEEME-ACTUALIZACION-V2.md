# Actualización v2 · Web de Ingeniería Metalúrgica

Hay tres partes, en este orden: **(1) GitHub**, **(2) el ID de Google para el panel** y **(3) el script de la planilla**.

---

## 1 · Subir la web nueva a GitHub (Git Bash)

1. Descomprimí `Metalurgica_Web_v2.zip` en **Descargas**. Queda la carpeta `Metalurgica_Web_v2`.
2. En Git Bash:

```bash
cd ~/Downloads/Metalurgica_Web_Preinscripcion/sitio-web
cp -r ~/Downloads/Metalurgica_Web_v2/sitio-web/. .
git add -A
git commit -m "Web v2: postas, videos, fotos nuevas, panel con Google y roles"
git push
```

> ⚠️ La carpeta `apps-script` **nunca** se sube a GitHub.

---

## 2 · Crear el "ID de cliente de Google" para el panel (gratis, una sola vez)

Conviene hacerlo con la cuenta **ingenieriametalurgicafrc@gmail.com**.

1. Entrá a https://console.cloud.google.com/ → arriba, **Seleccionar proyecto → Proyecto nuevo**. Nombre: `Metalurgica Web` → **Crear**.
2. Menú ☰ → **APIs y servicios → Pantalla de consentimiento de OAuth** (o "Google Auth Platform").
   - Nombre de la app: `Panel Metalúrgica UTN` · Email de asistencia: el del Departamento.
   - Público: **Externo** → completar el email de contacto → **Crear**.
   - En **Público**, tocá **Publicar app** (así cualquier cuenta autorizada puede entrar; no pide verificación porque solo usa nombre y email).
3. **Clientes → Crear cliente** → Tipo: **Aplicación web** → Nombre: `Panel web`.
   - **Orígenes de JavaScript autorizados** → agregá estas dos direcciones:
     - `https://ahumadaceleste.github.io`
     - `https://ingenieria-metalurgica-utn.github.io`
   - No hace falta completar "URI de redireccionamiento". → **Crear**.
4. Copiá el **ID de cliente**. Termina en `.apps.googleusercontent.com`. No es secreto: puede estar en la web.
5. Pegalo en **dos lugares**:
   - En GitHub, archivo `assets/js/config.js` → `GOOGLE_CLIENT_ID: 'PEGAR_ACÁ',`
     (✏️ editar → Commit changes; o editalo en tu carpeta y hacé `git add -A`, `git commit -m "ID Google"`, `git push`).
   - En el script de la planilla (paso 3) → `const GOOGLE_CLIENT_ID = 'PEGAR_ACÁ';`

---

## 3 · Actualizar el script de la planilla

1. Planilla **Consultas aspirantes 2027 (WEB)** → **Extensiones → Apps Script**.
2. Borrá todo el contenido de `Código.gs`, pegá `apps-script/Code.gs` (v2) y completá `GOOGLE_CLIENT_ID`. Guardá (💾).
3. Elegí la función **`inicializar`** → **Ejecutar** → aceptá los permisos. Ahora pide uno nuevo, "conectarse a un servicio externo": es para verificar las cuentas de Google.
   Se crean las hojas **Usuarios**, **Auditoría** y **Papelera**.
4. **Implementar → Administrar implementaciones →** elegí la que empieza con **AKfycbwC7i7…** → **✏️** → Versión: **Nueva versión** → **Implementar**.

### Probar
- Web: el contador muestra **27 +** las preinscripciones reales.
- Panel: **Acceder con Google** con `ingenieriametalurgicafrc@gmail.com`. Desde **Usuarios** se habilita al resto del equipo.

---

## Cómo funciona la seguridad
| Qué | Cómo |
|---|---|
| Ingreso al panel | Solo con cuenta de Google autorizada; no hay contraseñas guardadas |
| Roles | **Admin**: todo, incluso usuarios, exportar y eliminar · **Editor**: seguimiento · **Lector**: consulta sin datos personales |
| Sesión | Vence a las 2 horas sin uso; quitar un acceso desconecta en el momento |
| Datos personales | CUIL, domicilio, nacimiento: solo se cargan al abrir "Datos personales" de una ficha, y queda registrado |
| Auditoría | Hoja "Auditoría": ingresos, accesos a datos, ediciones, bajas, exportaciones, eliminaciones |
| Eliminar | Pasa a la hoja "Papelera", con copia de seguridad |
| Formularios | Anti-spam, límite de envíos y validación de CUIL |
| Web | HTTPS + políticas de seguridad (CSP) en cada página + política de privacidad (Ley 25.326) |

**Recomendaciones:**
- La planilla compartida solo con quien corresponda (Compartir → acceso restringido).
- Verificación en 2 pasos activada en la cuenta del Departamento.
- No reenviar los CSV exportados por WhatsApp.
