/**
 * INGENIERÍA METALÚRGICA · UTN FRC — v2
 * Preinscripciones, consultas y seguimiento de aspirantes.
 * Backend en Google Apps Script → guarda en la planilla, envía emails y controla el acceso al panel.
 *
 * SEGURIDAD
 * - El panel se abre SOLO con cuenta de Google. No hay contraseñas guardadas.
 * - Solo entran los emails autorizados (hoja "Usuarios"). El administrador principal (ADMIN_PRINCIPAL)
 *   siempre tiene acceso y es quien habilita a los demás desde el panel.
 * - Roles: admin (todo) · editor (seguimiento) · lector (solo consulta, sin datos personales).
 * - Las sesiones vencen solas (SESION_MINUTOS). Todo lo sensible queda registrado en la hoja "Auditoría".
 * - Los datos personales (CUIL, domicilio, nacimiento…) solo viajan al abrir una ficha.
 * - Eliminar no borra para siempre: mueve el registro a la hoja "Papelera".
 *
 * ACTUALIZAR EL SCRIPT: pegá este archivo completo, guardá, ejecutá "inicializar" una vez (acepta permisos)
 * y luego Implementar → Administrar implementaciones → ✏️ → Versión: "Nueva versión" → Implementar.
 */

/* ======================= CONFIGURACIÓN ======================= */

const ADMIN_PRINCIPAL    = 'ingenieriametalurgicafrc@gmail.com';  // Administrador/a principal (no se puede quitar)
const GOOGLE_CLIENT_ID   = '';  // ← ID de cliente OAuth de Google (termina en .apps.googleusercontent.com)
const EMAIL_AVISOS       = 'ingenieriametalurgicafrc@gmail.com';  // Recibe un aviso por cada consulta nueva
const CONFIRMAR_ASPIRANTE = true;     // Email de "¡Recibimos tus datos!" a quien se preinscribe
const CONTADOR_INICIAL   = 27;        // El contador público arranca en este número y suma cada preinscripción
const CIERRE_INSCRIPCION = '2026-11-29';
const SESION_MINUTOS     = 120;       // Duración de una sesión del panel
const SITIOS_PERMITIDOS  = [          // Direcciones de la web (para los links de los emails)
  'https://ingenieria-metalurgica-utn.github.io/',
  'https://ahumadaceleste.github.io/ingenieriametalurgica.utn/'
];

const SHEET_ID   = '';             // Vacío = la planilla donde está creado el script
const HOJA       = 'Hoja 1';       // Aspirantes (una fila por persona)
const HOJA_LOG   = 'Seguimiento';
const HOJA_USERS = 'Usuarios';
const HOJA_AUDIT = 'Auditoría';
const HOJA_PAPEL = 'Papelera';

const COLS = [
  'ID', 'Fecha', 'Tipo', 'Estado', 'Situación',
  'Apellidos', 'Nombres', 'Email', 'Teléfono', 'DNI', 'CUIL', 'Fecha de nacimiento',
  'Estado civil', 'Nacionalidad', 'País', 'Dirección', 'Barrio', 'Localidad', 'Provincia', 'Código postal',
  'Colegio', 'Secundario técnico', 'Egreso', 'Cómo nos conoció', 'Consulta',
  'Legajo', 'Nota Matemática', 'Nota Física', 'Nota Intro Vida Univ.',
  'Req: Datos validados', 'Req: Agendado / WhatsApp', 'Req: Preinscripción SysAcad', 'Req: Pre-cursillo',
  'Req: Matemática', 'Req: Física', 'Req: Intro Vida Univ.', 'Req: Equivalencia',
  'Req: Documentación', 'Req: Requisitos académicos', 'Req: Inscripción Guaraní',
  'Próximo contacto', 'Último contacto', 'Observaciones',
  'Motivo de baja', 'Detalle de baja', 'Etapa de baja', 'Fecha de baja', 'Respuesta del aspirante (baja)', 'Token baja',
  'Actualizado'
];
const COLS_LOG   = ['Fecha', 'ID', 'Persona', 'Acción', 'Detalle', 'Próximo contacto', 'Usuario'];
const COLS_USERS = ['Email', 'Nombre', 'Rol', 'Activo', 'Alta', 'Alta por', 'Último acceso'];
const COLS_AUDIT = ['Fecha', 'Usuario', 'Acción', 'ID', 'Detalle'];
const COLS_PAPEL = ['Fecha', 'Eliminado por', 'Hoja', 'ID', 'Persona', 'Datos'];

/* Datos personales: no viajan en el listado, solo al abrir la ficha (queda auditado) */
const SENSIBLES = ['CUIL', 'Fecha de nacimiento', 'Estado civil', 'Nacionalidad', 'País', 'Dirección', 'Barrio', 'Código postal', 'Token baja'];

const CAMPOS_FORM = {
  apellidos: 'Apellidos', nombres: 'Nombres', email: 'Email', telefono: 'Teléfono', cuil: 'CUIL',
  nacimiento: 'Fecha de nacimiento', estadoCivil: 'Estado civil', nacionalidad: 'Nacionalidad', pais: 'País',
  direccion: 'Dirección', barrio: 'Barrio', localidad: 'Localidad', provincia: 'Provincia', cp: 'Código postal',
  colegio: 'Colegio', tecnico: 'Secundario técnico', egreso: 'Egreso', origen: 'Cómo nos conoció', consulta: 'Consulta'
};
const NO_EDITABLES = ['ID', 'Fecha', 'Actualizado', 'Token baja', 'Respuesta del aspirante (baja)', 'Etapa de baja', 'Fecha de baja'];
const ESTADOS = ['Consultante', 'Ingresante', 'Estudiante', 'Baja'];
const ROLES = { lector: 1, editor: 2, admin: 3 };
const MOTIVOS_BAJA = ['No aprobó el ingreso', 'Eligió otra carrera', 'Eligió otra universidad', 'Motivos laborales',
  'Motivos económicos', 'Distancia / traslado', 'Horario de cursado', 'Motivos personales o familiares',
  'Cambio de especialidad', 'No respondió los contactos', 'Otro'];

/* ======================= ENTRADAS WEB ======================= */

function doGet(e) { return responder_((e && e.parameter) || {}); }

function doPost(e) {
  let p = {};
  try { if (e && e.postData && e.postData.contents) p = JSON.parse(e.postData.contents); }
  catch (err) { p = {}; }
  return responder_(p);
}

function responder_(p) {
  let out;
  try {
    const a = String(p.action || 'count');
    switch (a) {
      case 'count':     out = publico_(); break;
      case 'submit':    out = enviar_(p); break;
      case 'motivo':    out = motivoAspirante_(p); break;
      case 'login':     out = login_(p); break;
      case 'logout':    out = logout_(p); break;
      case 'me':        out = conSesion_(p, 'lector', function (u) { return { ok: true, user: u }; }); break;
      case 'list':      out = conSesion_(p, 'lector', listar_); break;
      case 'get':       out = conSesion_(p, 'editor', ficha_); break;
      case 'update':    out = conSesion_(p, 'editor', actualizar_); break;
      case 'log':       out = conSesion_(p, 'editor', registrarAccion_); break;
      case 'baja':      out = conSesion_(p, 'editor', baja_); break;
      case 'delete':    out = conSesion_(p, 'admin', eliminar_); break;
      case 'export':    out = conSesion_(p, 'admin', exportar_); break;
      case 'users':     out = conSesion_(p, 'admin', usuarios_); break;
      case 'saveUser':  out = conSesion_(p, 'admin', guardarUsuario_); break;
      case 'audit':     out = conSesion_(p, 'admin', verAuditoria_); break;
      default:          out = { ok: false, error: 'Acción desconocida' };
    }
  } catch (err) {
    console.error(err);
    out = { ok: false, error: String(err && err.message || err) };
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

/* ======================= PÚBLICO ======================= */

function publico_() {
  const cache = CacheService.getScriptCache();
  const hit = cache.get('publico');
  if (hit) return JSON.parse(hit);
  const n = leer_().filas.filter(function (r) { return r['Tipo'] === 'Preinscripción'; }).length;
  const out = { ok: true, preinscriptos: n + CONTADOR_INICIAL, cierre: CIERRE_INSCRIPCION };
  cache.put('publico', JSON.stringify(out), 30);
  return out;
}

function enviar_(p) {
  if (p.website) return { ok: true };                       // trampa anti-spam
  if (!limite_('envios', 30, 600)) return { ok: false, error: 'Recibimos muchos envíos seguidos. Probá de nuevo en unos minutos.' };
  const d = p.datos || {};
  const tipo = p.tipo === 'consulta' ? 'Consulta' : 'Preinscripción';
  const v = {};
  Object.keys(CAMPOS_FORM).forEach(function (k) { v[CAMPOS_FORM[k]] = limpiar_(d[k], k === 'consulta' ? 1500 : 160); });

  if (!v['Nombres'] || !v['Apellidos']) return { ok: false, error: 'Faltan nombre y apellido' };
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v['Email'])) return { ok: false, error: 'Email inválido' };
  if (String(v['Teléfono']).replace(/\D/g, '').length < 8) return { ok: false, error: 'Teléfono inválido' };
  v['DNI'] = '';
  if (tipo === 'Preinscripción' || v['CUIL']) {
    const c = String(v['CUIL']).replace(/\D/g, '');
    if (!cuilValido_(c)) return { ok: false, error: 'CUIL inválido' };
    v['CUIL'] = c.slice(0, 2) + '-' + c.slice(2, 10) + '-' + c.slice(10);
    v['DNI'] = String(parseInt(c.slice(2, 10), 10));
  }
  if (tipo === 'Preinscripción') {
    const req = ['Fecha de nacimiento', 'Dirección', 'Localidad', 'Provincia', 'Colegio'];
    for (let i = 0; i < req.length; i++) if (!v[req[i]]) return { ok: false, error: 'Falta: ' + req[i] };
  }
  const clave = v['DNI'] || v['Email'].toLowerCase();
  if (!limite_('p_' + clave, 3, 600)) return { ok: false, error: 'Ya recibimos tus datos. Si necesitás corregir algo, escribinos.' };

  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  let id, esNuevo = true;
  try {
    const datos = leer_();
    const previa = datos.filas.filter(function (r) {
      return (v['DNI'] && String(r['DNI']).replace(/\D/g, '') === v['DNI']) ||
             (!v['DNI'] && String(r['Email']).toLowerCase() === v['Email'].toLowerCase());
    })[0];
    const ahora = new Date();
    if (previa) {
      esNuevo = false; id = previa['ID'];
      const cambios = {};
      Object.keys(v).forEach(function (c) { if (v[c]) cambios[c] = v[c]; });
      if (tipo === 'Preinscripción') cambios['Tipo'] = 'Preinscripción';
      if (v['Consulta']) cambios['Consulta'] = (previa['Consulta'] ? previa['Consulta'] + '\n---\n' : '') + v['Consulta'];
      cambios['Actualizado'] = ahora;
      escribirFila_(datos, previa._fila, cambios);
      log_(id, v['Apellidos'] + ', ' + v['Nombres'], 'Formulario web', 'Volvió a enviar el formulario (' + tipo + ')', '', 'web');
    } else {
      id = 'IM-' + Utilities.formatDate(ahora, 'America/Argentina/Cordoba', 'yyMMdd') + '-' + Utilities.getUuid().slice(0, 4).toUpperCase();
      const fila = {};
      Object.keys(v).forEach(function (c) { fila[c] = v[c]; });
      fila['ID'] = id; fila['Fecha'] = ahora; fila['Tipo'] = tipo; fila['Estado'] = 'Consultante';
      fila['Situación'] = 'Nuevo · sin contactar'; fila['Actualizado'] = ahora;
      datos.sh.appendRow(datos.enc.map(function (c) { return c in fila ? fila[c] : ''; }));
    }
    SpreadsheetApp.flush();
  } finally { lock.releaseLock(); }
  CacheService.getScriptCache().remove('publico');

  try { avisarOficina_(id, tipo, v, esNuevo); } catch (err) { console.warn('Aviso no enviado: ' + err); }
  if (CONFIRMAR_ASPIRANTE) { try { confirmarAspirante_(tipo, v); } catch (err) { console.warn('Confirmación no enviada: ' + err); } }
  return Object.assign({ ok: true, nuevo: esNuevo }, publico_());
}

/** El aspirante responde por qué se dio de baja (link de un solo uso enviado por email). */
function motivoAspirante_(p) {
  if (!limite_('motivo', 30, 600)) return { ok: false, error: 'Probá de nuevo en unos minutos.' };
  const id = String(p.id || ''), t = String(p.t || '');
  const motivo = limpiar_(p.motivo, 80), detalle = limpiar_(p.detalle, 800);
  if (!id || t.length < 20 || !motivo) return { ok: false, error: 'Link inválido' };
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const datos = leer_();
    const f = datos.filas.filter(function (r) { return String(r['ID']) === id; })[0];
    if (!f || String(f['Token baja']) !== t) return { ok: false, error: 'Este link ya se usó o no es válido. ¡Gracias igual!' };
    escribirFila_(datos, f._fila, {
      'Respuesta del aspirante (baja)': motivo + (detalle ? ' — ' + detalle : ''), 'Token baja': '', 'Actualizado': new Date()
    });
    log_(id, f['Apellidos'] + ', ' + f['Nombres'], 'Respuesta de baja', motivo + (detalle ? ' — ' + detalle : ''), '', 'aspirante');
    SpreadsheetApp.flush();
  } finally { lock.releaseLock(); }
  return { ok: true };
}

/* ======================= SESIONES (Google) ======================= */

function login_(p) {
  if (!GOOGLE_CLIENT_ID) return { ok: false, error: 'Falta configurar GOOGLE_CLIENT_ID en el script.' };
  if (!limite_('login', 40, 600)) return { ok: false, error: 'Demasiados intentos. Esperá unos minutos.' };
  const tok = String(p.idToken || '');
  if (tok.length < 100) return { ok: false, auth: false, error: 'Inicio de sesión inválido' };
  const r = UrlFetchApp.fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(tok), { muteHttpExceptions: true });
  if (r.getResponseCode() !== 200) return { ok: false, auth: false, error: 'No se pudo verificar la cuenta de Google' };
  const info = JSON.parse(r.getContentText());
  if (info.aud !== GOOGLE_CLIENT_ID || String(info.email_verified) !== 'true' || Number(info.exp) * 1000 < Date.now()) {
    return { ok: false, auth: false, error: 'Cuenta de Google no verificada' };
  }
  const email = String(info.email).toLowerCase();
  const u = usuario_(email);
  if (!u) { audit_(email, 'Acceso denegado', '', 'Cuenta no autorizada'); return { ok: false, auth: false, error: 'La cuenta ' + email + ' no está autorizada. Pedile acceso al administrador.' }; }
  if (!u.nombre && info.name) u.nombre = String(info.name);
  const token = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
  CacheService.getScriptCache().put('s_' + token, JSON.stringify({ email: u.email, rol: u.rol, nombre: u.nombre }), SESION_MINUTOS * 60);
  marcarAcceso_(email, info.name);
  audit_(email, 'Inicio de sesión', '', u.rol);
  return { ok: true, token: token, user: u, minutos: SESION_MINUTOS };
}

function logout_(p) {
  if (p.token) CacheService.getScriptCache().remove('s_' + String(p.token));
  return { ok: true };
}

function conSesion_(p, rolMin, fn) {
  const cache = CacheService.getScriptCache();
  const raw = p.token ? cache.get('s_' + String(p.token)) : null;
  if (!raw) return { ok: false, auth: false, error: 'Tu sesión venció. Volvé a ingresar.' };
  const s = JSON.parse(raw);
  const u = usuario_(s.email);                         // se revalida en cada pedido: un usuario dado de baja pierde el acceso al instante
  if (!u) { cache.remove('s_' + p.token); return { ok: false, auth: false, error: 'Tu acceso fue dado de baja.' }; }
  if (ROLES[u.rol] < ROLES[rolMin]) return { ok: false, error: 'Tu rol (' + u.rol + ') no permite esta acción.' };
  cache.put('s_' + p.token, JSON.stringify({ email: u.email, rol: u.rol, nombre: u.nombre }), SESION_MINUTOS * 60);
  p._user = u;
  return fn(u, p);
}

function usuario_(email) {
  email = String(email || '').toLowerCase();
  if (!email) return null;
  if (email === ADMIN_PRINCIPAL.toLowerCase()) return { email: email, nombre: 'Administración', rol: 'admin', principal: true };
  const f = filasDe_(HOJA_USERS, COLS_USERS).filter(function (r) { return String(r['Email']).toLowerCase() === email; })[0];
  if (!f || !on_(f['Activo']) || !ROLES[String(f['Rol'])]) return null;
  return { email: email, nombre: String(f['Nombre'] || ''), rol: String(f['Rol']) };
}

/* ======================= PANEL ======================= */

function listar_(u) {
  const filas = leer_().filas.map(function (r) {
    const o = {};
    Object.keys(r).forEach(function (k) {
      if (k === '_fila' || SENSIBLES.indexOf(k) >= 0) return;
      o[k] = serial_(r[k]);
    });
    if (u.rol === 'lector') { o['DNI'] = enmascarar_(o['DNI']); o['Email'] = enmascarar_(o['Email']); o['Teléfono'] = enmascarar_(o['Teléfono']); o['Observaciones'] = ''; o['Consulta'] = ''; }
    else o['DNI'] = enmascarar_(o['DNI']);
    o._tieneToken = !!r['Token baja'];
    return o;
  });
  const log = u.rol === 'lector' ? [] : filasDe_(HOJA_LOG, COLS_LOG).map(function (r) {
    const o = {}; COLS_LOG.forEach(function (c) { o[c] = serial_(r[c]); }); return o;
  });
  return { ok: true, user: u, filas: filas, log: log, estados: ESTADOS, motivos: MOTIVOS_BAJA, cierre: CIERRE_INSCRIPCION };
}

function ficha_(u, p) {
  const r = buscar_(p.id);
  if (!r) return { ok: false, error: 'No se encontró el registro' };
  const o = {};
  Object.keys(r.fila).forEach(function (k) { if (k !== '_fila' && k !== 'Token baja') o[k] = serial_(r.fila[k]); });
  audit_(u.email, 'Vio datos personales', p.id, '');
  return { ok: true, ficha: o };
}

function actualizar_(u, p) {
  const id = String(p.id || ''), cambios = p.cambios || {};
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const r = buscar_(id);
    if (!r) return { ok: false, error: 'No se encontró ' + id };
    const limpio = {};
    Object.keys(cambios).forEach(function (c) {
      if (COLS.indexOf(c) >= 0 && NO_EDITABLES.indexOf(c) < 0) limpio[c] = limpiar_(cambios[c], ['Observaciones', 'Consulta'].indexOf(c) >= 0 ? 3000 : 200);
    });
    if (limpio['Estado'] && ESTADOS.indexOf(limpio['Estado']) < 0) return { ok: false, error: 'Estado inválido' };
    if (limpio['Estado'] === 'Baja' && r.fila['Estado'] !== 'Baja') return { ok: false, error: 'Para dar de baja usá el botón "Dar de baja" (pide el motivo).' };
    if (limpio['CUIL']) {
      const c = limpio['CUIL'].replace(/\D/g, '');
      if (!cuilValido_(c)) return { ok: false, error: 'CUIL inválido' };
      limpio['CUIL'] = c.slice(0, 2) + '-' + c.slice(2, 10) + '-' + c.slice(10);
      limpio['DNI'] = String(parseInt(c.slice(2, 10), 10));
    } else delete limpio['DNI'];
    limpio['Actualizado'] = new Date();
    escribirFila_(r.datos, r.fila._fila, limpio);
    const persona = r.fila['Apellidos'] + ', ' + r.fila['Nombres'];
    if (limpio['Estado'] && limpio['Estado'] !== r.fila['Estado']) log_(id, persona, 'Cambio de estado', r.fila['Estado'] + ' → ' + limpio['Estado'], '', u.email);
    audit_(u.email, 'Editó', id, Object.keys(limpio).filter(function (k) { return k !== 'Actualizado'; }).join(', '));
    SpreadsheetApp.flush();
  } finally { lock.releaseLock(); }
  CacheService.getScriptCache().remove('publico');
  return listar_(u);
}

function registrarAccion_(u, p) {
  const id = String(p.id || ''), accion = limpiar_(p.accion, 40) || 'Nota';
  const detalle = limpiar_(p.detalle, 2000), prox = limpiar_(p.proximo, 20);
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const r = buscar_(id);
    if (!r) return { ok: false, error: 'No se encontró ' + id };
    log_(id, r.fila['Apellidos'] + ', ' + r.fila['Nombres'], accion, detalle, prox, u.email);
    const cambios = { 'Último contacto': new Date(), 'Actualizado': new Date() };
    if (prox || p.limpiarProximo) cambios['Próximo contacto'] = prox;
    if (p.situacion) cambios['Situación'] = limpiar_(p.situacion, 80);
    escribirFila_(r.datos, r.fila._fila, cambios);
    SpreadsheetApp.flush();
  } finally { lock.releaseLock(); }
  return listar_(u);
}

function baja_(u, p) {
  const id = String(p.id || ''), motivo = limpiar_(p.motivo, 80), detalle = limpiar_(p.detalle, 1000);
  if (MOTIVOS_BAJA.indexOf(motivo) < 0) return { ok: false, error: 'Elegí un motivo de baja' };
  let r, token = '';
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    r = buscar_(id);
    if (!r) return { ok: false, error: 'No se encontró ' + id };
    const f = r.fila;
    const etapa = etapaActual_(f);
    const cambios = {
      'Estado': 'Baja', 'Situación': motivo === 'No respondió los contactos' ? 'Sin comunicación' : 'Abandonó',
      'Motivo de baja': motivo, 'Detalle de baja': detalle, 'Etapa de baja': etapa, 'Fecha de baja': new Date(),
      'Próximo contacto': '', 'Actualizado': new Date()
    };
    if (p.enviarEmail && f['Email']) { token = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, ''); cambios['Token baja'] = token; }
    escribirFila_(r.datos, f._fila, cambios);
    log_(id, f['Apellidos'] + ', ' + f['Nombres'], 'Baja', motivo + (detalle ? ' — ' + detalle : '') + ' (etapa: ' + etapa + ')', '', u.email);
    audit_(u.email, 'Dio de baja', id, motivo);
    SpreadsheetApp.flush();
  } finally { lock.releaseLock(); }
  let emailOk = false;
  if (token) {
    try { emailMotivo_(r.fila, id, token, p.sitio); emailOk = true; } catch (err) { console.warn('Email de baja no enviado: ' + err); }
  }
  return Object.assign(listar_(u), { emailEnviado: emailOk });
}

function eliminar_(u, p) {
  const id = String(p.id || '');
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  let persona = '';
  try {
    const r = buscar_(id);
    if (!r) return { ok: false, error: 'No se encontró ' + id };
    persona = r.fila['Apellidos'] + ', ' + r.fila['Nombres'];
    const pap = hoja_(HOJA_PAPEL, COLS_PAPEL), ahora = new Date();
    const copia = {}; Object.keys(r.fila).forEach(function (k) { if (k !== '_fila') copia[k] = serial_(r.fila[k]); });
    pap.appendRow([ahora, u.email, HOJA, id, persona, JSON.stringify(copia)]);
    r.datos.sh.deleteRow(r.fila._fila);
    // Seguimiento: borrar de abajo hacia arriba
    const sl = hoja_(HOJA_LOG, COLS_LOG), encL = encabezados_(sl), jId = encL.indexOf('ID'), n = sl.getLastRow();
    if (n > 1 && jId >= 0) {
      const vals = sl.getRange(2, 1, n - 1, encL.length).getValues();
      for (let i = vals.length - 1; i >= 0; i--) {
        if (String(vals[i][jId]) === id) { pap.appendRow([ahora, u.email, HOJA_LOG, id, persona, JSON.stringify(vals[i].map(serial_))]); sl.deleteRow(i + 2); }
      }
    }
    audit_(u.email, 'Eliminó', id, persona);
    SpreadsheetApp.flush();
  } finally { lock.releaseLock(); }
  CacheService.getScriptCache().remove('publico');
  return listar_(u);
}

function exportar_(u) {
  const filas = leer_().filas.map(function (r) {
    const o = {}; Object.keys(r).forEach(function (k) { if (k !== '_fila' && k !== 'Token baja') o[k] = serial_(r[k]); }); return o;
  });
  audit_(u.email, 'Exportó la base', '', filas.length + ' registros');
  return { ok: true, filas: filas };
}

function usuarios_(u) {
  const lista = [{ Email: ADMIN_PRINCIPAL, Nombre: 'Administración (principal)', Rol: 'admin', Activo: 'Sí', principal: true }]
    .concat(filasDe_(HOJA_USERS, COLS_USERS).map(function (r) { const o = {}; COLS_USERS.forEach(function (c) { o[c] = serial_(r[c]); }); return o; }));
  return { ok: true, usuarios: lista };
}

function guardarUsuario_(u, p) {
  const email = String(p.email || '').trim().toLowerCase();
  const rol = String(p.rol || ''), activo = p.activo === false ? 'No' : 'Sí', nombre = limpiar_(p.nombre, 80);
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return { ok: false, error: 'Email inválido' };
  if (email === ADMIN_PRINCIPAL.toLowerCase()) return { ok: false, error: 'El administrador principal no se puede modificar.' };
  if (!ROLES[rol]) return { ok: false, error: 'Rol inválido' };
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const sh = hoja_(HOJA_USERS, COLS_USERS), enc = encabezados_(sh), n = sh.getLastRow();
    let fila = 0;
    if (n > 1) sh.getRange(2, 1, n - 1, enc.length).getValues().forEach(function (v, i) { if (String(v[enc.indexOf('Email')]).toLowerCase() === email) fila = i + 2; });
    const vals = { 'Email': email, 'Nombre': nombre, 'Rol': rol, 'Activo': activo };
    if (fila) Object.keys(vals).forEach(function (k) { sh.getRange(fila, enc.indexOf(k) + 1).setValue(vals[k]); });
    else { vals['Alta'] = new Date(); vals['Alta por'] = u.email; sh.appendRow(enc.map(function (c) { return c in vals ? vals[c] : ''; })); }
    audit_(u.email, fila ? 'Modificó usuario' : 'Habilitó usuario', '', email + ' · ' + rol + ' · activo: ' + activo);
    SpreadsheetApp.flush();
  } finally { lock.releaseLock(); }
  return usuarios_(u);
}

function verAuditoria_(u) {
  const rows = filasDe_(HOJA_AUDIT, COLS_AUDIT).slice(-300).reverse().map(function (r) {
    const o = {}; COLS_AUDIT.forEach(function (c) { o[c] = serial_(r[c]); }); return o;
  });
  return { ok: true, auditoria: rows };
}

/* ======================= EMAILS ======================= */

function avisarOficina_(id, tipo, v, esNuevo) {
  if (!EMAIL_AVISOS) return;
  const filas = [
    ['Tipo', tipo + (esNuevo ? '' : ' (ya estaba registrado/a)')], ['Nombre', v['Apellidos'] + ', ' + v['Nombres']],
    ['Email', v['Email']], ['Teléfono', v['Teléfono']], ['Localidad', v['Localidad'] + (v['Provincia'] ? ' · ' + v['Provincia'] : '')],
    ['Colegio', v['Colegio']], ['Cómo nos conoció', v['Cómo nos conoció']], ['Consulta', v['Consulta']]
  ].filter(function (r) { return r[1]; });
  const tel = String(v['Teléfono']).replace(/\D/g, '');
  const html =
    '<div style="font-family:Arial,sans-serif;max-width:560px">' +
    '<div style="background:#001484;color:#fff;padding:18px 20px;border-radius:12px 12px 0 0">' +
    '<div style="font-size:12px;letter-spacing:2px;color:#4ED6FF;font-weight:bold">INGENIERÍA METALÚRGICA · UTN FRC</div>' +
    '<div style="font-size:20px;font-weight:bold;margin-top:4px">Nueva ' + tipo.toLowerCase() + '</div></div>' +
    '<table style="width:100%;border-collapse:collapse;border:1px solid #e3e6f5">' +
    filas.map(function (r) {
      return '<tr><td style="padding:8px 12px;background:#f4f6ff;font-weight:bold;width:150px;border-bottom:1px solid #e3e6f5">' + esc_(r[0]) +
             '</td><td style="padding:8px 12px;border-bottom:1px solid #e3e6f5;white-space:pre-wrap">' + esc_(r[1]) + '</td></tr>';
    }).join('') + '</table>' +
    '<p style="margin-top:16px">' +
    (tel ? '<a href="https://wa.me/' + whatsapp_(tel) + '" style="background:#1DA851;color:#fff;padding:10px 14px;border-radius:8px;text-decoration:none;font-weight:bold">Escribir por WhatsApp</a> ' : '') +
    '<a href="mailto:' + esc_(v['Email']) + '" style="background:#E8185A;color:#fff;padding:10px 14px;border-radius:8px;text-decoration:none;font-weight:bold">Responder por email</a></p>' +
    '<p style="color:#5A6394;font-size:12px">ID ' + id + '. Los datos personales completos están en el panel de aspirantes.</p></div>';
  MailApp.sendEmail({ to: EMAIL_AVISOS, replyTo: v['Email'], name: 'Web Ingeniería Metalúrgica',
    subject: '🟢 Nueva ' + tipo.toLowerCase() + ': ' + v['Apellidos'] + ', ' + v['Nombres'], htmlBody: html });
}

function confirmarAspirante_(tipo, v) {
  const pre = tipo === 'Preinscripción';
  const html =
    '<div style="font-family:Arial,sans-serif;max-width:560px;color:#0B1446">' +
    '<div style="background:#001484;color:#fff;padding:22px;border-radius:12px">' +
    '<div style="font-size:12px;letter-spacing:2px;color:#F5AB12;font-weight:bold">INGENIERÍA METALÚRGICA · UTN FRC</div>' +
    '<div style="font-size:22px;font-weight:bold;margin-top:6px">¡Hola ' + esc_(v['Nombres']) + '! Recibimos tus datos 🙌</div></div>' +
    '<p>' + (pre ? 'Tu <b>preinscripción</b> quedó registrada.' : 'Recibimos tu <b>consulta</b>.') +
    ' En breve alguien del Departamento de Ingeniería Metalúrgica se va a comunicar con vos.</p>' +
    (pre ? '<p><b>Próximos pasos del ingreso</b></p><ol>' +
      '<li>Te contactamos para validar tus datos y sumarte al grupo de aspirantes.</li>' +
      '<li>Te invitamos al <b>pre-cursillo específico de Metalúrgica</b>.</li>' +
      '<li>Rendís los 3 módulos de ingreso: Matemática, Física e Introducción a la Vida Universitaria.</li></ol>' : '') +
    '<p>Las inscripciones cierran el <b>' + fechaLarga_(CIERRE_INSCRIPCION) + '</b>.</p>' +
    '<p>¿Dudas? Respondé este email · Tel. 0351-5986019 · Instagram @ingenieriametalurgicautn</p>' +
    '<p style="color:#5A6394;font-size:12px">Usamos tus datos solo para acompañarte en el ingreso (Ley 25.326). Si querés que los eliminemos, respondé este email.</p></div>';
  MailApp.sendEmail({ to: v['Email'], replyTo: EMAIL_AVISOS, name: 'Ingeniería Metalúrgica UTN FRC',
    subject: pre ? '¡Recibimos tu preinscripción a Ingeniería Metalúrgica!' : 'Recibimos tu consulta · Ingeniería Metalúrgica UTN FRC', htmlBody: html });
}

function emailMotivo_(f, id, token, sitio) {
  const base = SITIOS_PERMITIDOS.indexOf(String(sitio)) >= 0 ? String(sitio) : SITIOS_PERMITIDOS[0];
  const link = base + 'motivo.html?id=' + encodeURIComponent(id) + '&t=' + token;
  const html =
    '<div style="font-family:Arial,sans-serif;max-width:560px;color:#0B1446">' +
    '<div style="background:#001484;color:#fff;padding:22px;border-radius:12px">' +
    '<div style="font-size:12px;letter-spacing:2px;color:#4ED6FF;font-weight:bold">INGENIERÍA METALÚRGICA · UTN FRC</div>' +
    '<div style="font-size:21px;font-weight:bold;margin-top:6px">Hola ' + esc_(f['Nombres']) + ', ¿nos ayudás con una respuesta?</div></div>' +
    '<p>Vimos que por ahora no vas a continuar con el ingreso a Ingeniería Metalúrgica. ¡Está todo bien! ' +
    'Nos ayudaría mucho saber el motivo para mejorar el acompañamiento a futuros aspirantes. Es 1 clic y es anónimo para las estadísticas.</p>' +
    '<p style="margin:22px 0"><a href="' + link + '" style="background:#E8185A;color:#fff;padding:13px 18px;border-radius:10px;text-decoration:none;font-weight:bold">Contarnos el motivo</a></p>' +
    '<p>Si en algún momento querés retomar, escribinos: las puertas están abiertas.</p></div>';
  MailApp.sendEmail({ to: f['Email'], replyTo: EMAIL_AVISOS, name: 'Ingeniería Metalúrgica UTN FRC',
    subject: '¿Nos contás por qué no seguiste? · Ingeniería Metalúrgica UTN FRC', htmlBody: html });
}

/* ======================= HOJAS ======================= */

function libro_() {
  const activa = SpreadsheetApp.getActiveSpreadsheet();
  if (SHEET_ID) { try { return SpreadsheetApp.openById(SHEET_ID); } catch (e) { if (activa) return activa; throw e; } }
  if (!activa) throw new Error('El script no está dentro de una planilla: completá SHEET_ID con el ID de la planilla.');
  return activa;
}

function hoja_(nombre, cols) {
  const lb = libro_();
  let sh = lb.getSheetByName(nombre);
  if (!sh) sh = lb.insertSheet(nombre);
  const enc = encabezados_(sh);
  const faltan = cols.filter(function (c) { return enc.indexOf(c) < 0; });
  if (faltan.length) {
    const desde = enc.filter(String).length ? sh.getLastColumn() + 1 : 1;
    sh.getRange(1, desde, 1, faltan.length).setValues([faltan])
      .setFontWeight('bold').setBackground('#001484').setFontColor('#ffffff').setWrap(true);
    if (sh.getFrozenRows() < 1) sh.setFrozenRows(1);
  }
  return sh;
}

function encabezados_(sh) {
  const n = Math.max(sh.getLastColumn(), 1);
  return sh.getRange(1, 1, 1, n).getValues()[0].map(function (c) { return String(c).trim(); });
}

function leer_() {
  const sh = hoja_(HOJA, COLS);
  const enc = encabezados_(sh);
  const n = sh.getLastRow();
  const filas = [];
  if (n > 1) {
    sh.getRange(2, 1, n - 1, enc.length).getValues().forEach(function (vals, i) {
      if (!vals.some(function (x) { return x !== ''; })) return;
      const o = { _fila: i + 2 };
      enc.forEach(function (c, j) { if (c) o[c] = vals[j]; });
      filas.push(o);
    });
  }
  return { sh: sh, enc: enc, filas: filas };
}

function buscar_(id) {
  const datos = leer_();
  const fila = datos.filas.filter(function (r) { return String(r['ID']) === String(id); })[0];
  return fila ? { datos: datos, fila: fila } : null;
}

function escribirFila_(datos, nFila, cambios) {
  Object.keys(cambios).forEach(function (c) {
    const j = datos.enc.indexOf(c);
    if (j >= 0) datos.sh.getRange(nFila, j + 1).setValue(cambios[c]);
  });
}

function filasDe_(nombre, cols) {
  const sh = hoja_(nombre, cols);
  const enc = encabezados_(sh);
  const n = sh.getLastRow();
  if (n < 2) return [];
  return sh.getRange(2, 1, n - 1, enc.length).getValues()
    .filter(function (v) { return v.some(function (x) { return x !== ''; }); })
    .map(function (vals) { const o = {}; enc.forEach(function (c, j) { if (c) o[c] = vals[j]; }); return o; });
}

function log_(id, persona, accion, detalle, proximo, usuario) {
  const sh = hoja_(HOJA_LOG, COLS_LOG), enc = encabezados_(sh);
  const v = { 'Fecha': new Date(), 'ID': id, 'Persona': persona, 'Acción': accion, 'Detalle': detalle, 'Próximo contacto': proximo || '', 'Usuario': usuario || '' };
  sh.appendRow(enc.map(function (c) { return c in v ? v[c] : ''; }));
}

function audit_(usuario, accion, id, detalle) {
  try { hoja_(HOJA_AUDIT, COLS_AUDIT).appendRow([new Date(), usuario, accion, id || '', detalle || '']); } catch (e) { console.warn(e); }
}

function marcarAcceso_(email, nombre) {
  const sh = hoja_(HOJA_USERS, COLS_USERS), enc = encabezados_(sh), n = sh.getLastRow();
  if (n < 2) return;
  sh.getRange(2, 1, n - 1, enc.length).getValues().forEach(function (v, i) {
    if (String(v[enc.indexOf('Email')]).toLowerCase() === email) {
      sh.getRange(i + 2, enc.indexOf('Último acceso') + 1).setValue(new Date());
      if (!v[enc.indexOf('Nombre')] && nombre) sh.getRange(i + 2, enc.indexOf('Nombre') + 1).setValue(nombre);
    }
  });
}

/* ======================= UTILIDADES ======================= */

function etapaActual_(f) {
  const ok = function (k) { return on_(f[k]); };
  if (f['Estado'] === 'Consultante') return ok('Req: Datos validados') ? 'Consultante · contactado' : 'Consultante · sin validar';
  if (ok('Req: Inscripción Guaraní') || ok('Req: Documentación')) return 'Ingresante · documentación';
  if (ok('Req: Equivalencia') || (ok('Req: Matemática') && ok('Req: Física') && ok('Req: Intro Vida Univ.'))) return 'Ingresante · cursillo aprobado';
  if (ok('Req: Matemática') || ok('Req: Física') || ok('Req: Intro Vida Univ.') || ok('Req: Pre-cursillo')) return 'Ingresante · cursando el ingreso';
  return f['Estado'] === 'Estudiante' ? 'Estudiante' : 'Ingresante · inicio';
}

function cuilValido_(c) {
  if (!/^(20|23|24|27|30|33|34)\d{9}$/.test(c)) return false;
  const w = [5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
  let s = 0; for (let i = 0; i < 10; i++) s += Number(c[i]) * w[i];
  let dv = 11 - (s % 11); if (dv === 11) dv = 0; if (dv === 10) dv = 9;
  return dv === Number(c[10]);
}

function limite_(clave, max, seg) {
  const cache = CacheService.getScriptCache(), k = 'rl_' + clave;
  const n = Number(cache.get(k) || 0);
  if (n >= max) return false;
  cache.put(k, String(n + 1), seg);
  return true;
}

function on_(v) { return /^(✓|si|sí|x|ok|true|1)$/i.test(String(v == null ? '' : v).trim()); }
function enmascarar_(v) { const s = String(v || ''); if (!s) return ''; if (s.indexOf('@') > 0) return s[0] + '•••@' + s.split('@')[1]; return '•••' + s.slice(-3); }
function limpiar_(v, max) {
  let s = String(v == null ? '' : v).trim().slice(0, max || 200);
  if (/^[=+\-@]/.test(s) && !/^-?\d/.test(s)) s = "'" + s;   // evita fórmulas inyectadas
  return s;
}
function serial_(v) { return v instanceof Date ? Utilities.formatDate(v, 'America/Argentina/Cordoba', "yyyy-MM-dd'T'HH:mm:ss") : v; }
function esc_(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
function whatsapp_(tel) { let t = tel.replace(/^0/, ''); if (t.indexOf('54') === 0) return t; t = t.replace(/^(\d{2,4})15/, '$1'); return '549' + t; }
function fechaLarga_(iso) {
  const m = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
  const p = iso.split('-'); return Number(p[2]) + ' de ' + m[Number(p[1]) - 1];
}

/** Ejecutalo una vez desde el editor: crea las hojas y pide los permisos (planilla, email y verificación de Google). */
function inicializar() {
  hoja_(HOJA, COLS); hoja_(HOJA_LOG, COLS_LOG); hoja_(HOJA_USERS, COLS_USERS); hoja_(HOJA_AUDIT, COLS_AUDIT); hoja_(HOJA_PAPEL, COLS_PAPEL);
  UrlFetchApp.fetch('https://oauth2.googleapis.com/tokeninfo?id_token=x', { muteHttpExceptions: true });  // autoriza la verificación de cuentas
  Logger.log('Listo. Emails disponibles hoy: ' + MailApp.getRemainingDailyQuota());
}
